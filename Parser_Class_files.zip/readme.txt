This code has been built and tested on Ubuntu Linux.

two files are included:

parser.dbl - the actual class file
test.dbl     - code used to test the methods.

compile and link as follows:

dbproto parser.dbl

dbl parser
dbl test

dblink test parser

dbr test


hope you find this useful!